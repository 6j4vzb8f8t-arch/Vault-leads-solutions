# Leads Vault Solutions

Static website for Leads Vault Solutions.

## Deploy to Vercel

1. Upload this folder to a GitHub repository, or drag the project folder into Vercel.
2. Vercel detects it as a static site automatically.
3. Deploy.
4. Connect your custom `.com` domain from Vercel's Domains settings.

## Before launch

Edit `script.js` and replace:

`leads@yourdomain.com`

with your actual business email.

The contact form currently opens the visitor's email application. For a real database/CRM form, connect it later to Formspree, HubSpot, GoHighLevel, or your own backend.
