function toggleMenu(){
  const nav=document.getElementById("navMenu");
  nav.classList.toggle("mobile-open");
}
function submitForm(e){
  e.preventDefault();
  const form=e.target;
  const data=new FormData(form);
  const msg=document.getElementById("formMessage");
  const email=data.get("email");
  const subject=encodeURIComponent("New Lead Request - Leads Vault Solutions");
  const body=encodeURIComponent(
`Name: ${data.get("name")}
Company: ${data.get("company")}
Email: ${email}
Phone: ${data.get("phone")}
Market: ${data.get("market")}
Lead Type: ${data.get("leadType")}

Requirements:
${data.get("message")}`
  );
  window.location.href=`mailto:leads@yourdomain.com?subject=${subject}&body=${body}`;
  msg.textContent="Your email app will open with the lead request. Replace the email address in script.js with your real business email.";
}
document.querySelectorAll('a[href^="#"]').forEach(a=>{
  a.addEventListener("click",()=>document.getElementById("navMenu")?.classList.remove("mobile-open"));
});
